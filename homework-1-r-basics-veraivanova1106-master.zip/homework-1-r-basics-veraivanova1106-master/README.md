# Econometrics 2018
## Homework 1
